<?php
/**
 * Plugin Name:    Look Ruby Core
 * Plugin URI:     https://themeforest.net/user/theme-ruby/
 * Description:    features for Look, this is required plugin (important) for this theme.
 * Version:        5.6
 * Author:         Theme-Ruby
 * Author URI:     https://themeforest.net/user/theme-ruby/
 * @package        look-ruby-core
 * @copyright (c) 2018, Theme-Ruby
 */

//  No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LOOK_CORE_VERSION', '5.6' );
define( 'LOOK_CORE_URL', plugin_dir_url( __FILE__ ) );
define( 'LOOK_CORE_PATH', plugin_dir_path( __FILE__ ) );

if ( ! class_exists( 'look_ruby_plugin_core' ) ) {
	class look_ruby_plugin_core {

		protected static $instance = null;

		function __construct() {

			$this->plugin_loader();
			add_action( 'init', array( $this, 'init' ) );
			add_action( 'widgets_init', array( $this, 'register_widgets' ) );
		}

		static function get_instance() {

			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}

		public function init() {

			load_plugin_textdomain( 'look-core', false, LOOK_CORE_URL . '/languages/' );
			look_ruby_shortcodes::get_instance();

			add_filter( 'user_contactmethods', array( $this, 'additional_author_info' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 1 );
		}

		// enqueue_scripts
		static function enqueue_scripts() {

			wp_enqueue_style( 'look_ruby_plugin_core_style', LOOK_CORE_URL . 'assets/core.css', array(), LOOK_CORE_VERSION, 'all' );
			wp_enqueue_script( 'look_ruby_plugin_core_scripts', LOOK_CORE_URL . 'assets/core.js', array( 'jquery' ), LOOK_CORE_VERSION, true );
		}

		/**
		 * @return array
		 * author info
		 */
		static function additional_author_info() {

			return array(
				'job'               => esc_html__( 'Job Name', 'look-core' ),
				'facebook'          => esc_html__( 'Facebook', 'look-core' ),
				'look_ruby_twitter' => esc_html__( 'Twitter', 'look-core' ),
				'pinterest'         => esc_html__( 'Pinterest', 'look-core' ),
				'bloglovin'         => esc_html__( 'Bloglovin', 'look-core' ),
				'linkedin'          => esc_html__( 'Linkedin', 'look-core' ),
				'tumblr'            => esc_html__( 'Tumblr', 'look-core' ),
				'flickr'            => esc_html__( 'Flickr', 'look-core' ),
				'instagram'         => esc_html__( 'Instagram', 'look-core' ),
				'skype'             => esc_html__( 'Skype', 'look-core' ),
				'myspace'           => esc_html__( 'Myspace', 'look-core' ),
				'youtube'           => esc_html__( 'Youtube', 'look-core' ),
				'vkontakte'         => esc_html__( 'Vkontakte', 'look-core' ),
				'reddit'            => esc_html__( 'Reddit', 'look-core' ),
				'snapchat'          => esc_html__( 'Snapchat', 'look-core' ),
				'digg'              => esc_html__( 'Digg', 'look-core' ),
				'dribbble'          => esc_html__( 'Dribbble', 'look-core' ),
				'soundcloud'        => esc_html__( 'Soundcloud', 'look-core' ),
				'vimeo'             => esc_html__( 'Vimeo', 'look-core' ),
				'rss'               => esc_html__( 'Rss', 'look-core' ),
			);
		}

		// plugin loader
		public function plugin_loader() {

			if ( ! function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			if ( ! is_plugin_active( 'redux-framework/redux-framework.php' ) ) {
				include_once LOOK_CORE_PATH . 'lib/redux-framework/framework.php';
			}

			if ( ! is_plugin_active( 'meta-box/meta-box.php' ) ) {
				include_once LOOK_CORE_PATH . 'lib/meta-box/meta-box.php';
			}

			// includes
			include_once LOOK_CORE_PATH . 'composer/setup.php';
			include_once LOOK_CORE_PATH . 'composer/templates.php';

			include_once LOOK_CORE_PATH . 'lib/taxonomy-meta.php';
			include_once LOOK_CORE_PATH . 'inc/redux.php';
			include_once LOOK_CORE_PATH . 'inc/shortcodes.php';
			include_once LOOK_CORE_PATH . 'inc/ad_support.php';
			include_once LOOK_CORE_PATH . 'inc/social_media.php';
			include_once LOOK_CORE_PATH . 'inc/social_bar.php';
			include_once LOOK_CORE_PATH . 'inc/social_data.php';
			include_once LOOK_CORE_PATH . 'inc/social_share_count.php';
			include_once LOOK_CORE_PATH . 'inc/social_fan.php';
			include_once LOOK_CORE_PATH . 'inc/social_share_post.php';
			include_once LOOK_CORE_PATH . 'inc/like_box.php';
			require_once LOOK_CORE_PATH . 'inc/action.php';

			// widgets
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_social_counter.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_social_icon.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_ad.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_instagram.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_flickr.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_fb.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_youtube.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_tweet.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_about.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_subscribe.php';
			require_once LOOK_CORE_PATH . 'widgets/tfooter_widget_instagram.php';
			require_once LOOK_CORE_PATH . 'widgets/bc_widget_banner.php';
			require_once LOOK_CORE_PATH . 'widgets/sb_widget_post.php';
		}

		// register widgets
		public function register_widgets() {

			register_widget( 'look_ruby_banner_widget' );
			register_widget( 'look_ruby_about_widget' );
			register_widget( 'look_ruby_sb_ad_widget' );
			register_widget( 'look_ruby_fanpage_fb' );
			register_widget( 'look_ruby_flickr' );
			register_widget( 'look_ruby_sb_instagram' );
			register_widget( 'look_ruby_sb_social_counter' );
			register_widget( 'look_ruby_social_widget' );
			register_widget( 'look_ruby_sb_subscribe_widget' );
			register_widget( 'look_ruby_twitter_widget' );
			register_widget( 'look_ruby_youtube_widget' );
			register_widget( 'look_ruby_tfooter_instagram' );
			register_widget( 'look_ruby_sb_widget_post' );
		}
	}
}

look_ruby_plugin_core::get_instance();