<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'display_post_states', 'look_show_composer_state' );
add_action( 'add_meta_boxes', 'look_register_composer_meta', 0 );
add_action( 'admin_enqueue_scripts', 'look_composer_scripts' );
add_action( 'admin_footer', 'look_composer_js_templates' );
add_action( 'save_post', 'look_save_composer_data', 10 );

/** register metabox */
if ( ! function_exists( 'look_register_composer_meta' ) ) {
	function look_register_composer_meta() {
		if ( ! is_admin() ) {
			return false;
		}
		$section = array(
			'title'      => esc_html__( 'RUBY COMPOSER', 'rbc' ),
			'context'    => 'normal',
			'post_types' => array( 'page' ),
			'priority'   => 'high',
		);

		add_meta_box( 'rbc-global-meta', $section['title'], 'look_composer_global_panel', $section['post_types'], $section['context'], $section['priority'], $section );

		return false;
	}
}

/** rbc meta nonce */
if ( ! function_exists( 'look_composer_global_panel' ) ) {
	function look_composer_global_panel() {
		wp_nonce_field( basename( __FILE__ ), 'rbc_meta_nonce' );
	}
}


if ( ! function_exists( 'look_composer_scripts' ) ) {
	function look_composer_scripts() {

		global $pagenow;
		if ( ( 'post.php' == $pagenow || 'post-new.php' == $pagenow ) && get_current_screen()->post_type == 'page' ) {
			if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'elementor' ) {
				return;
			}

			wp_enqueue_style( 'look_ruby_composer_style', LOOK_CORE_URL . '/composer/assets/composer.css', array(), LOOK_CORE_VERSION, 'all' );
			wp_register_script( 'look_ruby_composer_script', LOOK_CORE_URL . '/composer/assets/composer.js', array(
				'jquery',
				'wp-util'
			), LOOK_CORE_VERSION, true );

			$templates     = look_composer_templates();
			$sections      = look_composer_sections();
			$composer_data = look_composer_get_data();

			wp_localize_script( 'look_ruby_composer_script', 'look_setup_sections', $sections );
			wp_localize_script( 'look_ruby_composer_script', 'look_composer_template', $templates );
			if ( function_exists( 'look_composer_blocks' ) ) {
				$blocks = look_composer_blocks();
				wp_localize_script( 'look_ruby_composer_script', 'look_setup_blocks', $blocks );

			}
			wp_localize_script( 'look_ruby_composer_script', 'look_page_composer_data', $composer_data );
			wp_enqueue_script( 'look_ruby_composer_script' );
		}
	}
}

/** show composer stage */
if ( ! function_exists( 'look_show_composer_state' ) ) {
	function look_show_composer_state( $states ) {
		global $post;
		global $pagenow;
		if ( 'edit.php' == $pagenow && get_current_screen()->post_type == 'page' ) {
			if ( 'page' == get_post_type( $post->ID ) && 'page-composer.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
				$states[] = esc_html__( 'Ruby Composer', 'rbc' );
			}
		}

		return $states;
	}
}

/** get composer data */
if ( ! function_exists( 'look_composer_get_data' ) ) {
	function look_composer_get_data() {

		global $post;
		$data = array();
		if ( isset( $post->ID ) && 'page-composer.php' == get_post_meta( $post->ID, '_wp_page_template', true ) ) {
			$data = get_post_meta( $post->ID, 'look_ruby_composer_page_data', true );
			$data = stripslashes_deep( $data );
		}

		return $data;
	}
}


//  init composer data
if ( ! function_exists( 'look_init_composer_data' ) ) {
	function look_save_composer_data() {

		if ( empty( $_POST['post_ID'] ) ) {
			return false;
		}

		$page_id     = esc_attr( $_POST['post_ID'] );
		$is_autosave = wp_is_post_autosave( $page_id );
		$is_revision = wp_is_post_revision( $page_id );

		$is_valid_nonce = ( isset( $_POST['rbc_meta_nonce'] ) && wp_verify_nonce( $_POST['rbc_meta_nonce'], basename( __FILE__ ) ) ) ? true : false;

		if ( $is_autosave || $is_revision || ! $is_valid_nonce ) {
			return false;
		}

		if ( empty( $_POST['post_type'] ) || 'page' != $_POST['post_type'] || ( ! empty( $_POST['action'] ) && 'inline-save' == $_POST['action'] ) ) {
			return false;
		}

		if ( empty( $_POST['rbc_js_loaded'] ) ) {
			return false;
		}

		$composer_data = array();

		if ( ! isset( $_POST['look_ruby_section_order'] ) ) {
			if ( 'page-composer.php' == get_post_meta( $page_id, '_wp_page_template', true ) ) {
				delete_post_meta( $page_id, 'look_ruby_composer_page_data' );
			}

			return false;
		};

		if ( ! array( $_POST['look_ruby_section_order'] ) ) {
			return false;
		}

		foreach ( $_POST['look_ruby_section_order'] as $id ) {

			// sanitize id
			$id = sanitize_text_field( $id );
			if ( ! isset( $_POST[ 'look_ruby_section_' . $id ] ) ) {
				return false;
			}

			$section_type = sanitize_text_field( $_POST[ 'look_ruby_section_' . $id ] );

			if ( $section_type == 'section_has_sidebar' ) {

				$section_sidebar          = '';
				$section_sidebar_position = '';
				$section_sidebar_sticky   = '';

				if ( ! empty ( $_POST[ 'look_ruby_sidebar_' . $id ] ) ) {
					$section_sidebar = sanitize_text_field( $_POST[ 'look_ruby_sidebar_' . $id ] );
				}
				if ( ! empty( $_POST[ 'look_ruby_sidebar_position_' . $id ] ) ) {
					$section_sidebar_position = sanitize_text_field( $_POST[ 'look_ruby_sidebar_position_' . $id ] );
				}

				if ( ! empty( $_POST[ 'look_ruby_meta_sidebar_sticky_' . $id ] ) ) {
					$section_sidebar_sticky = sanitize_text_field( $_POST[ 'look_ruby_meta_sidebar_sticky_' . $id ] );
				}

				$composer_data[ $id ]['section_sidebar']          = $section_sidebar;
				$composer_data[ $id ]['section_sidebar_position'] = $section_sidebar_position;
				$composer_data[ $id ]['section_sidebar_sticky']   = $section_sidebar_sticky;
			}

			$composer_data[ $id ]['section_type'] = $section_type;
			$composer_data[ $id ]['section_id']   = $id;

			// get child block
			if ( ! isset( $_POST['look_ruby_block_order'][ $id ] ) ) {
				continue;
			}

			$blocks_of_section = array_map( 'sanitize_text_field', $_POST['look_ruby_block_order'][ $id ] );

			// get all option and block
			$blocks = array();
			if ( is_array( $blocks_of_section ) ) {
				foreach ( $blocks_of_section as $block ) {
					$block_name = 'look_ruby_block_' . $block;

					// get block name
					$name                           = sanitize_text_field( $_POST[ $block_name ] );
					$blocks[ $block ]['block_name'] = $name;
					$blocks[ $block ]['block_id']   = $block;

					if ( isset( $_POST['look_ruby_block_option'][ $block_name ] ) ) {
						$block_options = $_POST['look_ruby_block_option'][ $block_name ];

						// get block option
						foreach ( $block_options as $option_name => $option ) {
							$option_name                                       = sanitize_text_field( $option_name );
							$option                                            = look_sanitize_input( $option_name, $option );
							$blocks[ $block ]['block_options'][ $option_name ] = $option;
						}
					}
				}
			}

			$composer_data[ $id ]['blocks'] = $blocks;
		}

		// save composer data
		update_post_meta( $page_id, 'look_ruby_composer_page_data', $composer_data );

		return false;
	}
}

/** look_sanitize_input */
if ( ! function_exists( 'look_sanitize_input' ) ) {
	function look_sanitize_input( $option_name = '', $option = '' ) {
		switch ( $option_name ) {
			case 'custom_html' :
			case 'shortcode' :
			case 'ad_script' :
				return addslashes( $option );
			case 'title_url'  :
			case 'image_url'  :
			case 'image_link' :
				return esc_url( $option );
			case 'category_ids' : {
				$options = array();
				if ( is_array( $option ) ) {
					foreach ( $option as $option_el ) {
						$options[] = sanitize_text_field( $option_el );
					}
				}

				return $options;
			}
			default :
				return sanitize_text_field( $option );
		}
	}
}