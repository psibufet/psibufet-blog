<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_tfooter_instagram' ) ) {
	class look_ruby_tfooter_instagram extends WP_Widget {
		
		function __construct() {
			$widget_ops = array(
				'classname'   => 'top-footer-widget-instagram',
				'description' => esc_html__( '[Top Footer Widget] Display Instagram image gird in top footer section', 'look-core' )
			);
			parent::__construct( 'look_ruby_tfooter_instagram', esc_html__( '[TOP FOOTER] - Instagram Grid*', 'look-core' ), $widget_ops );
		}

		//render widget
		function widget( $args, $instance ) {

			$title           = ( ! empty( $instance['title'] ) ) ? apply_filters( 'title', $instance['title'] ) : '';
			$title_url       = ( ! empty( $instance['title_url'] ) ) ? $instance['title_url'] : '';
			$instagram_token = ( ! empty( $instance['instagram_token'] ) ) ? $instance['instagram_token'] : '';
			$num_images      = ( ! empty( $instance['num_image'] ) ) ? $instance['num_image'] : '';
			$num_column      = ( ! empty( $instance['num_column'] ) ) ? $instance['num_column'] : 'col-xs-3';
			$click_popup     = ( ! empty( $instance['click_popup'] ) ) ? $instance['click_popup'] : '';
			$max_width       = ( ! empty( $instance['max_width'] ) ) ? $instance['max_width'] : '';
			$widget_id       = ( ! empty( $args['widget_id'] ) ) ? $args['widget_id'] : 0;

			if ( 'wrapper' == $max_width ) {
				$max_width = 'ruby-container';
			} else {
				$max_width = '';
			}

			echo $args['before_widget'];

			if ( ! empty( $title ) ) {
				if ( empty( $title_url ) ) {
					echo $args['before_title'] . $title . $args['after_title'];
				} else {
					echo $args['before_title'] . '<a href="' . esc_url( $title_url ) . '" target="_blank">' . esc_attr( $title ) . '</a>' . $args['after_title'];
				}
			}

			$counter        = 0;
			$data_instagram = get_transient( 'look_ruby_instagram_cache' );

			if ( empty( $data_instagram[ $widget_id ] ) ) {
				$data_images = look_ruby_instagram_data::get_data( $instagram_token, 'look_ruby_instagram_cache', $widget_id, $num_images );
			} else {
				$data_images = $data_instagram[ $widget_id ];
			};

			if ( ! empty( $data_images ) ) : ?>
				<div class="instagram-content-wrap row <?php echo ' ' . $max_width; ?>">
					<?php foreach ($data_images as $post_data) :
						$counter++ ; ?>
						<div class="footer-instagram-el <?php echo esc_attr($num_column) ?>">
							<div class="instagram-el-holder">
								<?php if ( ! empty( $click_popup ) )  : ?>
									<a href="<?php echo esc_url( $post_data['thumbnail_src'] ) ?>" class="instagram-popup-el cursor-zoom" data-source=""><img src="<?php echo esc_url($post_data['thumbnail_src']) ?>" alt=""></a>
								<?php else : ?>
									<a href="<?php echo esc_html( $post_data['link'] ); ?>" target="_blank"><img src="<?php echo esc_url($post_data['thumbnail_src']) ?>" alt=""></a>
								<?php endif; ?>
							</div>
						</div>
					<?php if ( $counter >= $num_images ) { break; }
					endforeach;  ?>
				</div>
				<?php if ( ! empty( $click_popup ) ) {
					wp_localize_script( 'look_ruby_main_script', 'look_ruby_tfooter_instagram_popup', '1' );
				} ?>
			<?php else : ?>
				<?php if ( is_string( $data_images ) ) : ?>
					<div class="is-center"><?php echo( strval( $data_images ) ); ?></div>
				<?php endif;
				endif;
			 echo $args['after_widget'];
		}


		//update forms
		function update($new_instance, $old_instance)
		{
			delete_transient( 'look_ruby_instagram_cache' );

			$instance                    = $old_instance;
			$instance['title']           = strip_tags( $new_instance['title'] );
			$instance['title_url']       = esc_html( $new_instance['title_url'] );
			$instance['instagram_token'] = strip_tags( $new_instance['instagram_token'] );
			$instance['num_image']       = absint( strip_tags( $new_instance['num_image'] ) );
			$instance['num_column']      = strip_tags( $new_instance['num_column'] );
			$instance['max_width']       = strip_tags( $new_instance['max_width'] );
			$instance['click_popup']     = strip_tags( $new_instance['click_popup'] );
			return $instance;
		}


		function form( $instance ) {
			$defaults = array(
				'title'           => esc_html__( 'Follow @ Instagram', 'look-core' ),
				'title_url'       => '',
				'max_width'       => 'full',
				'instagram_token' => '',
				'num_image'       => 7,
				'num_column'      => 'ruby-col-7',
				'click_popup'     => ''
			);
			$instance = wp_parse_args( (array) $instance, $defaults );	?>
			<p><?php echo html_entity_decode( esc_html__( 'How to Create an app and generate your Instagram access token on: <a target="_blank" href="https://instagram.themeruby.com/">Instagram access token tutorial</a> website</p>', 'look-core' ) ); ?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><strong><?php esc_html_e('Title:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('title_url')); ?>"><strong><?php esc_html_e('Instagram User URL:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title_url')); ?>" name="<?php echo esc_attr($this->get_field_name('title_url')); ?>" type="text" value="<?php echo esc_html($instance['title_url']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('instagram_token')); ?>"><strong><?php esc_html_e('Instagram Access Token:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('instagram_token')); ?>" name="<?php echo esc_attr($this->get_field_name('instagram_token')); ?>" type="text" value="<?php echo esc_attr($instance['instagram_token']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('num_image')); ?>"><strong><?php esc_html_e('Limit Image Number:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('num_image')); ?>" name="<?php echo esc_attr($this->get_field_name('num_image')); ?>" type="text" value="<?php echo esc_attr($instance['num_image']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'num_column' )); ?>"><strong><?php esc_html_e('Number of Columns:', 'look-core'); ?></strong></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'num_column' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'num_column' )); ?>" >
					<option value="col-xs-3" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'col-xs-3' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('4 columns', 'look-core'); ?></option>
					<option value="ruby-col-5" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'ruby-col-5' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('5 columns', 'look-core'); ?></option>
					<option value="col-xs-2" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'col-xs-2' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('6 columns', 'look-core'); ?></option>
					<option value="ruby-col-7" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'ruby-col-7' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('7 columns', 'look-core'); ?></option>
					<option value="ruby-col-8" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'ruby-col-8' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('8 columns', 'look-core'); ?></option>
					<option value="ruby-col-9" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'ruby-col-9' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('9 columns', 'look-core'); ?></option>
					<option value="ruby-col-10" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'ruby-col-10' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('10 columns', 'look-core'); ?></option>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'max_width' )); ?>"><strong><?php esc_html_e('Width of Grid:', 'look-core'); ?></strong></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'max_width' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'max_width' )); ?>" >
					<option value="full" <?php if( !empty($instance['max_width']) && $instance['max_width'] == 'full' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Full Width', 'look-core'); ?></option>
					<option value="wrapper" <?php if( !empty($instance['max_width']) && $instance['max_width'] == 'wrapper' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Has Wrapper', 'look-core'); ?></option>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'click_popup' )); ?>"><?php esc_html_e('Popup When Click:','look-core') ?></label>
				<input class="widefat" type="checkbox" id="<?php echo esc_attr($this->get_field_id( 'click_popup' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'click_popup' )); ?>" value="checked" <?php if( !empty( $instance['click_popup'] ) ) echo 'checked="checked"'; ?>  />
			</p>
		<?php
		}
	}
}