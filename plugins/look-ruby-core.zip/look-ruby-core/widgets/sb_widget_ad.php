<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_sb_ad_widget' ) ) {
	class look_ruby_sb_ad_widget extends WP_Widget {

		function __construct() {
			$widget_ops = array('classname' => 'sb-widget-ad', 'description' => esc_html__('[Widget] Display your custom ads, your banner JS or Google Adsense code, Support Google Ads Responsive', 'look-core'));
			parent::__construct('look_ruby_sb_ad_widget', esc_html__('[SIDEBAR-FOOTER] Advertisement Box', 'look-core'), $widget_ops);
		}

		function widget( $args, $instance ) {

			echo $args['before_widget'];

			$instance = wp_parse_args( $instance, array(
				'title'           => '',
				'url'             => '',
				'image_url'       => '',
				'google_ads'       => '',
				'ad_size'         => 11,
				'ad_size_desktop' => 11,
				'ad_size_table'   => 11,
				'ad_size_mobile'  => 11,
			) );

			$settings                    = array();
			$settings['title']           = apply_filters( 'widget_title', $instance['title'] );
			$settings['image']           = $instance['image_url'];
			$settings['destination']     = $instance['url'];
			$settings['ad_script']       = $instance['google_ads'];
			$settings['id']              = $args['widget_id'];
			$settings['ad_size']         = $instance['ad_size'];
			$settings['ad_size_desktop'] = $instance['ad_size_desktop'];
			$settings['ad_size_table']   = $instance['ad_size_table'];
			$settings['ad_size_mobile']  = $instance['ad_size_mobile'];

			?><div class="ad-wrap clearfix">
				<?php if ( ! empty( $settings['image']  ) ) : ?>
					<?php look_ruby_ad_image( $settings ); ?>
				<?php else : ?>
					<?php look_ruby_ad_script($settings); ?>
				<?php endif; ?>
			</div>
			<?php  echo $args['after_widget'];
		}

		function update( $new_instance, $old_instance ) {
			$instance              = $old_instance;
			$instance['title']     = strip_tags( $new_instance['title'] );
			$instance['image_url'] = strip_tags( $new_instance['image_url'] );
			$instance['url']       = strip_tags( $new_instance['url'] );
			if ( current_user_can( 'unfiltered_html' ) ) {
				$instance['google_ads'] = $new_instance['google_ads'];
			} else {
				$instance['google_ads'] = wp_filter_post_kses( $new_instance['google_ads'] );
			}
			$instance['ad_size']         = strip_tags( $new_instance['ad_size'] );
			$instance['ad_size_desktop'] = strip_tags( $new_instance['ad_size_desktop'] );
			$instance['ad_size_table']   = strip_tags( $new_instance['ad_size_table'] );
			$instance['ad_size_mobile']  = strip_tags( $new_instance['ad_size_mobile'] );

			return $instance;
		}

		function form( $instance ) {
			$defaults = array(
				'title'           => esc_html__( '- Advertisement -', 'look-core' ),
				'url'             => '',
				'image_url'       => '',
				'google_ads'      => '',
				'ad_size'         => 11,
				'ad_size_desktop' => 11,
				'ad_size_table'   => 11,
				'ad_size_mobile'  => 11
			);
			$instance = wp_parse_args( (array) $instance, $defaults );  ?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><strong><?php esc_html_e('Title:', 'look-core'); ?></strong></label>
				<input class="widefat" type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('url')); ?>"><?php esc_html_e('Destination Link:', 'look-core'); ?></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('url')); ?>" name="<?php echo esc_attr($this->get_field_name('url')); ?>" type="text" value="<?php if( !empty($instance['url']) ) echo  esc_url($instance['url']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('image_url')); ?>"><?php esc_html_e('Image Attachment Link:', 'look-core'); ?></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('image_url')); ?>" name="<?php echo esc_attr($this->get_field_name('image_url')); ?>" type="text" value="<?php if ( ! empty( $instance['image_url'] ) ) echo esc_url($instance['image_url']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'google_ads' )); ?>"><?php esc_html_e('JS or Google AdSense Code:','look-core'); ?></label>
				<textarea rows="10" cols="50" id="<?php echo esc_attr($this->get_field_id( 'google_ads' )); ?>" name="<?php echo esc_attr($this->get_field_name('google_ads')); ?>" class="widefat"><?php echo $instance['google_ads']; ?></textarea>
			</p>
			<p><?php esc_html_e('Please remove custom ad if you use javascript ad code.','look-core'); ?></p>
			<h3><?php esc_html_e('Adsense Responsive', 'look-core'); ?></h3>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'ad_size' )); ?>"><?php esc_html_e('Ad Size', 'look-core'); ?></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'ad_size' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'ad_size' )); ?>">
					<option value="0" <?php if( !empty($instance['ad_size']) && $instance['ad_size'] == '0' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('From the Script', 'look-core'); ?></option>
					<option value="1" <?php if( !empty($instance['ad_size']) && $instance['ad_size'] == '1' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Custom Size (Settings Below)', 'look-core'); ?></option>
				</select>
			</p>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'ad_size_desktop' )); ?>"><?php esc_html_e('Ad Size Desktop:', 'look-core'); ?></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'ad_size_desktop' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'ad_size_desktop' )); ?>">
					<option value="0" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '0' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Hide on Desktop', 'look-core'); ?></option>
					<option value="1" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '1' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Leaderboard (728x90)', 'look-core'); ?></option>
					<option value="2" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '2' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Banner (468x60)', 'look-core'); ?></option>
					<option value="3" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '3' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Half banner (234x60)', 'look-core'); ?></option>
					<option value="4" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '4' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Button (125x125)', 'look-core'); ?></option>
					<option value="5" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '5' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Skyscraper (120x600)', 'look-core'); ?></option>
					<option value="6" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '6' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Wide Skyscraper (160x600)', 'look-core'); ?></option>
					<option value="7" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '7' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Small Rectangle (180x150)', 'look-core'); ?></option>
					<option value="8" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '8' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Vertical Banner (120 x 240)', 'look-core'); ?></option>
					<option value="9" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '9' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Small Square (200x200)', 'look-core'); ?></option>
					<option value="10" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '10' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Square (250x250)', 'look-core'); ?></option>
					<option value="11" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '11' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Medium Rectangle (300x250)', 'look-core'); ?></option>
					<option value="12" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '12' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Large Rectangle (336x280)', 'look-core'); ?></option>
					<option value="13" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '13' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Half Page (300x600)', 'look-core'); ?></option>
					<option value="14" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '14' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Portrait (300x1050)', 'look-core'); ?></option>
					<option value="15" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '15' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Mobile Banner (320x50)', 'look-core'); ?></option>
					<option value="16" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '16' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Large Leaderboard (970x90)', 'look-core'); ?></option>
					<option value="17" <?php if( !empty($instance['ad_size_desktop']) && $instance['ad_size_desktop'] == '17' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Billboard (970x250)', 'look-core'); ?></option>
				</select>
			</p>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'ad_size_table' )); ?>"><?php esc_html_e('Ad Size Table (Screen width < 800px):', 'look-core'); ?></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'ad_size_table' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'ad_size_table' )); ?>">
					<option value="0" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '0' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Hide on Table', 'look-core'); ?></option>
					<option value="1" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '1' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Leaderboard (728x90)', 'look-core'); ?></option>
					<option value="2" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '2' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Banner (468x60)', 'look-core'); ?></option>
					<option value="3" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '3' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Half banner (234x60)', 'look-core'); ?></option>
					<option value="4" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '4' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Button (125x125)', 'look-core'); ?></option>
					<option value="5" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '5' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Skyscraper (120x600)', 'look-core'); ?></option>
					<option value="6" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '6' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Wide Skyscraper (160x600)', 'look-core'); ?></option>
					<option value="7" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '7' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Small Rectangle (180x150)', 'look-core'); ?></option>
					<option value="8" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '8' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Vertical Banner (120 x 240)', 'look-core'); ?></option>
					<option value="9" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '9' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Small Square (200x200)', 'look-core'); ?></option>
					<option value="10" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '10' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Square (250x250)', 'look-core'); ?></option>
					<option value="11" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '11' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Medium Rectangle (300x250)', 'look-core'); ?></option>
					<option value="12" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '12' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Large Rectangle (336x280)', 'look-core'); ?></option>
					<option value="13" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '13' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Half Page (300x600)', 'look-core'); ?></option>
					<option value="14" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '14' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Portrait (300x1050)', 'look-core'); ?></option>
					<option value="15" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '15' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Mobile Banner (320x50)', 'look-core'); ?></option>
					<option value="16" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '16' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Large Leaderboard (970x90)', 'look-core'); ?></option>
					<option value="17" <?php if( !empty($instance['ad_size_table']) && $instance['ad_size_table'] == '17' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Billboard (970x250)', 'look-core'); ?></option>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'ad_size_mobile' )); ?>"><?php esc_html_e('Ad Size Desktop (Screen width < 500px ):', 'look-core'); ?></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'ad_size_mobile' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'ad_size_mobile' )); ?>">
					<option value="0" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '0' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Hide on Mobile', 'look-core'); ?></option>
					<option value="1" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '1' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Leaderboard (728x90)', 'look-core'); ?></option>
					<option value="2" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '2' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Banner (468x60)', 'look-core'); ?></option>
					<option value="3" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '3' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Half banner (234x60)', 'look-core'); ?></option>
					<option value="4" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '4' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Button (125x125)', 'look-core'); ?></option>
					<option value="5" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '5' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Skyscraper (120x600)', 'look-core'); ?></option>
					<option value="6" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '6' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Wide Skyscraper (160x600)', 'look-core'); ?></option>
					<option value="7" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '7' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Small Rectangle (180x150)', 'look-core'); ?></option>
					<option value="8" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '8' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Vertical Banner (120 x 240)', 'look-core'); ?></option>
					<option value="9" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '9' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Small Square (200x200)', 'look-core'); ?></option>
					<option value="10" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '10' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Square (250x250)', 'look-core'); ?></option>
					<option value="11" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '11' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Medium Rectangle (300x250)', 'look-core'); ?></option>
					<option value="12" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '12' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Large Rectangle (336x280)', 'look-core'); ?></option>
					<option value="13" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '13' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Half Page (300x600)', 'look-core'); ?></option>
					<option value="14" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '14' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Portrait (300x1050)', 'look-core'); ?></option>
					<option value="15" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '15' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Mobile Banner (320x50)', 'look-core'); ?></option>
					<option value="16" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '16' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Large Leaderboard (970x90)', 'look-core'); ?></option>
					<option value="17" <?php if( !empty($instance['ad_size_mobile']) && $instance['ad_size_mobile'] == '17' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_html_e('Billboard (970x250)', 'look-core'); ?></option>
				</select>
			</p>
		<?php
		}
	}
}