<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_youtube_widget' ) ) {
	class look_ruby_youtube_widget extends WP_Widget {

		function __construct() {
			$widget_ops = array('classname' => 'youtube-widget', 'description' => esc_attr__('[Sidebar Widget] Display a YouTube SUBSCRIBE box in sidebar sections','look-core'));
			parent::__construct('look_ruby_youtube_widget', esc_attr__('[SIDEBAR] - Youtube Subscribe', 'look-core'), $widget_ops);
		}

		function widget( $args, $instance ) {

			$title        = ( ! empty( $instance['title'] ) ) ? apply_filters( 'title', $instance['title'] ) : '';
			$channel_name = ( ! empty( $instance['channel_name'] ) ) ? $instance['channel_name'] : '';
			$channel_id   = ( ! empty( $instance['channel_id'] ) ) ? $instance['channel_id'] : '';

			echo $args['before_widget'];

			if ( $title ) {
				echo $args['before_title'] . $title . $args['after_title'];
			} ?>
			<div class="subscribe-youtube-wrap">
				<script src="https://apis.google.com/js/platform.js"></script>
				<?php if(!empty($channel_name)) : ?>
					<div class="g-ytsubscribe" data-channel="<?php echo esc_attr( $channel_name ) ?>" data-layout="default" data-count="default"></div>
				<?php elseif(!empty($channel_id)) : ?>
					<div class="g-ytsubscribe" data-channelid="<?php echo esc_attr($channel_id); ?>" data-layout="default" data-count="default"></div>
				<?php endif; ?>
			</div>
			<?php echo $args['after_widget'];
		}


		function update( $new_instance, $old_instance ) {
			$instance                 = $old_instance;
			$instance['title']        = strip_tags( $new_instance['title'] );
			$instance['channel_name'] = strip_tags( $new_instance['channel_name'] );
			$instance['channel_id']   = strip_tags( $new_instance['channel_id'] );

			return $instance;
		}


		function form( $instance ) {
			$defaults = array(
				'title'        => esc_attr__( 'Subscribe to our Channel', 'look-core' ),
				'channel_name' => '',
				'channel_ID'   => ''
			);
			$instance = wp_parse_args( (array) $instance, $defaults ); ?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_attr_e('Title :','look-core'); ?></label>
				<input  type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php if (!empty($instance['title'])) echo esc_attr($instance['title']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('channel_name')); ?>"><?php esc_attr_e('Channel Name:','look-core') ?></label>
				<input  type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('channel_name')); ?>" name="<?php echo esc_attr( $this->get_field_name( 'channel_name' ) ); ?>" value="<?php if (!empty($instance['channel_name'])) echo esc_attr($instance['channel_name']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('channel_ID')); ?>"><?php esc_attr_e('or Channel ID:','look-core') ?></label>
				<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('channel_id')); ?>" name="<?php echo esc_attr( $this->get_field_name( 'channel_id' ) ); ?>" value="<?php if (!empty($instance['channel_id'])) echo esc_attr($instance['channel_id']); ?>"/>
			</p>
		<?php
		}
	}
}

