<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_sb_instagram' ) ) {
	class look_ruby_sb_instagram extends WP_Widget {

		function __construct() {
			$widget_ops = array(
				'classname'   => 'sb-instagram-widget',
				'description' => esc_attr__( '[Sidebar Widget] Display Instagram Image grid in sidebar sections', 'look-core' )
			);
			parent::__construct( 'look_ruby_sb_instagram_widget', esc_attr__( '[SIDEBAR] - Instagram Grid', 'look-core' ), $widget_ops );
		}

		function widget( $args, $instance ) {

			$title           = ( ! empty( $instance['title'] ) ) ? apply_filters( 'title', $instance['title'] )  : '';
			$instagram_token = ( ! empty( $instance['instagram_token'] ) ) ? $instance['instagram_token'] : '';
			$num_images      = ( ! empty( $instance['num_image'] ) ) ? $instance['num_image'] : '';
			$num_column      = ( ! empty( $instance['num_column'] ) ) ? $instance['num_column'] : 'col-xs-3';
			$bottom_text     = ( ! empty( $instance['bottom_text'] ) ) ? $instance['bottom_text'] : '';
			$click_popup     = ( ! empty( $instance['click_popup'] ) ) ? $instance['click_popup'] : '';
			$widget_id       = ( ! empty( $args['widget_id'] ) ) ? $args['widget_id'] : 0;

			echo $args['before_widget'];

			if ( $title ) {
				echo $args['before_title'] . $title . $args['after_title'];
			}

			$counter        = 0;
			$data_instagram = get_transient( 'look_ruby_instagram_cache' );

			if ( empty( $data_instagram[ $widget_id ] ) ) {
				$data_images = look_ruby_instagram_data::get_data( $instagram_token, 'look_ruby_instagram_cache', $widget_id, $num_images );
			} else {
				$data_images = $data_instagram[ $widget_id ];
			};
			if ( ! empty( $data_images ) && is_array( $data_images ) ) : ?>
				<div class="instagram-content-wrap row clearfix">
					<?php foreach ($data_images as $post_data) :
						$counter ++; ?>
						<div class="instagram-el <?php echo esc_attr( $num_column ) ?>">
							<div class="instagram-el-holder">
								<?php if ( ! empty( $click_popup ) )  : ?>
									<a href="<?php echo esc_url( $post_data['thumbnail_src'] ) ?>" class="instagram-popup-el cursor-zoom" data-source=""><img src="<?php echo esc_url( $post_data['thumbnail_src'] ); ?>" alt=""></a>
								<?php else : ?>
									<a href="<?php echo esc_html( $post_data['link'] ); ?>" target="_blank"><img src="<?php echo esc_url( $post_data['thumbnail_src'] ) ?>" alt=""></a>
								<?php endif; ?>
							</div>
						</div>
					<?php  if ( $counter >= $num_images ) { break; }
					endforeach; ?>
				</div>
				<?php if ( ! empty( $bottom_text ) ) : ?>
					<div class="instagram-bottom-text"><?php echo $bottom_text; ?></div>
				<?php endif; ?>

				<?php if ( ! empty( $click_popup ) ) {
					wp_localize_script( 'look_ruby_main_script', 'look_ruby_sb_instagram_popup', '1' );
				} ?>

			<?php else :
				if ( is_string( $data_images ) ) {
					echo( strval( $data_images ) );
				};
			endif;

			echo $args['after_widget'];
		}


		function update( $new_instance, $old_instance ) {

			delete_transient( 'look_ruby_instagram_cache' );

			$instance                    = $old_instance;
			$instance['title']           = strip_tags( $new_instance['title'] );
			$instance['instagram_token'] = strip_tags( $new_instance['instagram_token'] );
			$instance['num_image']       = absint( strip_tags( $new_instance['num_image'] ) );
			$instance['bottom_text']     = addslashes( $new_instance['bottom_text'] );
			$instance['num_column']      = strip_tags( $new_instance['num_column'] );
			$instance['click_popup']     = strip_tags( $new_instance['click_popup'] );

			return $instance;
		}


		function form( $instance ) {
			$defaults = array(
				'title'           => 'instagram',
				'instagram_token' => '',
				'num_image'       => 9,
				'num_column'      => 'col-xs-4',
				'bottom_text'     => '',
				'click_popup'     => ''
			);
			$instance = wp_parse_args( (array) $instance, $defaults );

			?>
			<p><?php echo html_entity_decode( esc_html__( 'How to Create an app and generate your Instagram access token on: <a target="_blank" href="https://instagram.themeruby.com/">Instagram access token tutorial</a> website</p>', 'look-core' ) ); ?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><strong><?php esc_attr_e('Title:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>"/>
			</p>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id('instagram_token')); ?>"><strong><?php esc_attr_e('Instagram Access Token:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('instagram_token')); ?>" name="<?php echo esc_attr($this->get_field_name('instagram_token')); ?>" type="text" value="<?php echo esc_attr($instance['instagram_token']); ?>"/>
			</p>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id('num_image')); ?>"><strong><?php esc_attr_e('Limit Image Number:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('num_image')); ?>" name="<?php echo esc_attr($this->get_field_name('num_image')); ?>" type="text" value="<?php echo esc_attr($instance['num_image']); ?>"/>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'num_column' )); ?>"><strong><?php esc_attr_e('Number of Columns:', 'look-core'); ?></strong></label>
				<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'num_column' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'num_column' )); ?>" >
					<option value="col-xs-6" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'col-xs-6' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_attr_e('2 columns', 'look-core'); ?></option>
					<option value="col-xs-4" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'col-xs-4' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_attr_e('3 columns', 'look-core'); ?></option>
					<option value="col-xs-3" <?php if( !empty($instance['num_column']) && $instance['num_column'] == 'col-xs-3' ) echo "selected=\"selected\""; else echo ""; ?>><?php esc_attr_e('4 columns', 'look-core'); ?></option>
				</select>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('bottom_text')); ?>"><strong><?php esc_attr_e('Bottom Text:', 'look-core') ?></strong></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('bottom_text')); ?>" name="<?php echo esc_attr($this->get_field_name('bottom_text')); ?>" type="text" value="<?php echo esc_html($instance['bottom_text']); ?>"/>
			</p>

			<p>
				<label for="<?php echo esc_attr($this->get_field_id( 'click_popup' )); ?>"><?php esc_attr_e('Popup When Click:','look-core') ?></label>
				<input class="widefat" type="checkbox" id="<?php echo esc_attr($this->get_field_id( 'click_popup' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'click_popup' )); ?>" value="checked" <?php if( !empty( $instance['click_popup'] ) ) echo 'checked="checked"'; ?>  />
			</p>

		<?php
		}
	}
}
