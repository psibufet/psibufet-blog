<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'look_ruby_render_like_box' ) ) {
	function look_ruby_render_like_box() {
		
		//check settings
		$look_ruby_single_post_social_like = look_ruby_get_option( 'single_post_social_like' );
		if ( empty( $look_ruby_single_post_social_like ) ) {
			return false;
		}

		$look_ruby_twitter_user = get_the_author_meta( 'look_ruby_twitter' );
		if ( empty( $look_ruby_twitter_user ) ) {
			$look_ruby_twitter_user = look_ruby_get_option( 'look_ruby_twitter' );
		}
		if ( ! empty( $look_ruby_twitter_user ) ) {
			$look_ruby_pos = strpos( $look_ruby_twitter_user, 'twitter.com/' );
			if ( false === $look_ruby_pos ) {
				$look_ruby_twitter_user = get_bloginfo( 'name' );
			} else {
				$look_ruby_twitter_user = substr( $look_ruby_twitter_user, intval( $look_ruby_pos ) + 12 );
				$look_ruby_twitter_user = str_replace( '/', '', $look_ruby_twitter_user );
			}
		} else {
			$look_ruby_twitter_user = get_bloginfo( 'name' );
		}

		$look_ruby_protocol = 'http';
		if ( is_ssl() ) {
			$look_ruby_protocol = 'https';
		} ?>
		<div class="single-like-wrap">
			<ul class="single-like-inner">
				<li class="like-el">
					<a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php echo get_permalink() ?>" data-text="<?php echo  htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ); ?>" data-via="<?php echo urlencode( $look_ruby_twitter_user ); ?>" data-lang="en"></a>
					<script>!function (d, s, id) {
							var js, fjs = d.getElementsByTagName(s)[0];
							if (!d.getElementById(id)) {
								js = d.createElement(s);
								js.id = id;
								js.src = "//platform.twitter.com/widgets.js";
								fjs.parentNode.insertBefore(js, fjs);
							}}(document, "script", "twitter-wjs");
					</script>
				</li>
				<li class="like-el">
					<iframe src="<?php echo esc_attr( $look_ruby_protocol ); ?>://www.facebook.com/plugins/like.php?href=<?php echo get_permalink() ?>&amp;layout=button_count&amp;show_faces=false&amp;width=105&amp;action=like&amp;colorscheme=light&amp;height=21" style="border:none; overflow:hidden; width:105px; height:21px; background-color:transparent;"></iframe>
				</li>
				<li class="like-el">
					<div class="g-plusone" data-size="medium" data-href="<?php echo get_permalink() ?>"></div>
					<script type="text/javascript">
						(function() {
							var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
							po.src = "https://apis.google.com/js/plusone.js";
							var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
						})();
					</script>
				</li>
			</ul>
		</div>
	<?php }
}