<?php
//  No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_social_share_count' ) ) {
	class look_ruby_social_share_count {

		static function count_all_share() {

			//get URL
			$url = get_permalink();
			if ( empty( $url ) ) {
				return false;
			}

			$protocol = 'http';
			if ( is_ssl() ) {
				$protocol = 'https';
			}

			$url_snip             = look_ruby_convert_name_id( substr( $url, 0, 40 ) );
			$url_shares_transient = 'look_ruby_share_' . $url_snip;
			$cache                = get_transient( $url_shares_transient );

			if ( $cache !== false ) {
				return $cache;
			} else {

				$params = array(
					'timeout'   => 100,
					'sslverify' => false
				);

				//facebook
				$json_string = wp_remote_get( $protocol . '://graph.facebook.com/?ids=' . $url, $params );
				if ( ! is_wp_error( $json_string ) && isset( $json_string['body'] ) ) {
					$json              = json_decode( $json_string['body'], true );
					$count['facebook'] = isset( $json[ $url ]['share']['share_count'] ) ? intval( ( $json[ $url ]['share']['share_count'] ) ) : 0;
				} else {
					$count['facebook'] = 0;
				}

				//linkedin
				$json_string = wp_remote_get( $protocol .'://www.linkedin.com/countserv/count/share?url=$url&format=json', $params );
				if ( ! is_wp_error( $json_string ) && isset( $json_string['body'] ) ) {
					$json              = json_decode( $json_string['body'], true );
					$count['linkedin'] = isset( $json['count'] ) ? intval( $json['count'] ) : 0;
				} else {
					$count['linkedin'] = 0;
				}

				//Pinterest
				$json_string = wp_remote_get( $protocol .'://api.pinterest.com/v1/urls/count.json?url=' . $url, $params );
				if ( ! is_wp_error( $json_string ) && isset( $json_string['body'] ) ) {
					$json_string        = preg_replace( '/^receiveCount\((.*)\)$/', "\\1", $json_string['body'] );
					$json               = json_decode( $json_string, true );
					$count['pinterest'] = isset( $json['count'] ) ? intval( $json['count'] ) : 0;
				} else {
					$count['pinterest'] = 0;
				}

				//count all
				$count['all'] = $count['facebook'] + $count['pinterest'] + $count['linkedin'];

				set_transient( $url_shares_transient, $count, 60 * 60 * 5 );

				return $count;
			}
		}
	}
}

/**
 * change name to ID
 */
if ( ! function_exists( 'look_ruby_convert_name_id' ) ) {
	function look_ruby_convert_name_id( $name ) {
		$name = strtolower(strip_tags($name));
		$id = str_replace(array(' ', ',', '.', '"', "'", '/', "\\", '+', '=', ')', '(', '*', '&', '^', '%', '$', '#', '@', '!', '~', '`', '<', '>', '?', '[', ']', '{', '}', '|', ':',), '', $name);
		return $id;
	}
}
