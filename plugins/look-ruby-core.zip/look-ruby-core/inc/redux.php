<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**-------------------------------------------------------------------------------------------------------------------------
 * remove demo link
 */
if ( ! function_exists( 'look_ruby_redux_remove_demo_link' ) ) {
	function look_ruby_redux_remove_demo_link() {
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_filter( 'plugin_row_meta', array(
				ReduxFrameworkPlugin::get_instance(),
				'plugin_metalinks'
			), null, 2 );
		}
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_action( 'admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
		}
	}
}

add_action( 'init', 'look_ruby_redux_remove_demo_link', 1 );


if ( ! function_exists( 'look_ruby_get_option' ) ) {
	function look_ruby_get_option( $option_name ) {
		if ( empty( $GLOBALS['look_ruby_theme_options'][ $option_name ] ) ) {
			return false;
		} else {
			return $GLOBALS['look_ruby_theme_options'][ $option_name ];
		}

	}
}

/**-------------------------------------------------------------------------------------------------------------------------
 * @param $number
 *
 * @return int|string
 * show over 100k
 */
if ( ! function_exists( 'look_ruby_show_over_100k' ) ) {
	function look_ruby_show_over_100k( $number ) {
		$number = intval( $number );
		if ( $number > 999999 ) {
			$number = str_replace( '.00', '', number_format( ( $number / 1000000 ), 2 ) ) . esc_attr__( 'M', 'look-core' );
		} elseif ( $number > 999 ) {
			$number = str_replace( '.0', '', number_format( ( $number / 1000 ), 1 ) ) . esc_attr__( 'k', 'look-core' );
		}

		return $number;
	}
}

