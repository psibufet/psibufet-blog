<?php
//  No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_social_share_post' ) ) {
	class look_ruby_social_share_post {
		static function render_post_share_bar() {

			$twitter_user = get_the_author_meta( 'look_ruby_twitter' );
			if ( empty( $twitter_user ) ) {
				$twitter_user = look_ruby_get_option( 'look_ruby_twitter' );
			}

			if ( ! empty( $twitter_user ) ) {
				$pos = strpos( $twitter_user, 'twitter.com/' );
				if ( false === $pos ) {
					$twitter_user = get_bloginfo( 'name' );
				} else {
					$twitter_user = substr( $twitter_user, intval( $pos ) + 12 );
					$twitter_user = str_replace( '/', '', $twitter_user );
				}
			} else {
				$twitter_user = get_bloginfo( 'name' );
			}

			$protocol = 'http';
			if ( is_ssl() ) {
				$protocol = 'https';
			}

			$enable_facebook    = look_ruby_get_option( 'share_to_facebook' );
			$enable_twitter     = look_ruby_get_option( 'share_to_twitter' );
			$enable_linkedin    = look_ruby_get_option( 'share_to_linkedin' );
			$enable_pinterest   = look_ruby_get_option( 'share_to_pinterest' );
			$enable_tumblr      = look_ruby_get_option( 'share_to_tumblr' );
			$enable_vk          = look_ruby_get_option( 'share_to_vk' );
			$enable_reddit      = look_ruby_get_option( 'share_to_reddit' );
			$enable_email       = look_ruby_get_option( 'share_to_email' );
			$enable_whatsapp    = look_ruby_get_option( 'share_to_whatsapp' );

			//render
			$str = '';

			if ( ! empty( $enable_facebook ) ) {
				$str .= '<a class="share-bar-el icon-facebook" href="' . $protocol . '://www.facebook.com/sharer.php?u=' . urlencode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa-rb fa-facebook color-facebook"></i></a>';
			}
			if ( ! empty( $enable_twitter ) ) {
				$str .= '<a class="share-bar-el icon-twitter" href="https://twitter.com/intent/tweet?text=' . htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ) . '&amp;url=' . urlencode( get_permalink() ) . '&amp;via=' . urlencode( $twitter_user ) . '"><i class="fa-rb fa-twitter color-twitter"></i>';
				$str .= look_ruby_twitter_ember_script();
				$str .= '</a>';
			}
			if ( ! empty( $enable_pinterest ) ) {
				$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'look_ruby_840x500' );
				$str .= '<a class="share-bar-el icon-pinterest" href="' . $protocol . '://pinterest.com/pin/create/button/?url=' . urlencode( get_permalink() ) . '&amp;media=' . ( ! empty( $image[0] ) ? $image[0] : '' ) . '&description=' . htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa-rb fa-pinterest"></i></a>';
			}
			if ( ! empty ( $enable_linkedin ) ) {
				$str .= '<a class="share-bar-el icon-linkedin" href="' . $protocol . '://linkedin.com/shareArticle?mini=true&amp;url=' . urlencode( get_permalink() ) . '&amp;title=' . htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa-rb fa-linkedin"></i></a>';
			}
			if ( ! empty( $enable_tumblr ) ) {
				$str .= ' <a class="share-bar-el icon-tumblr" href="' . $protocol . '://www.tumblr.com/share/link?url=' . urlencode( get_permalink() ) . '&amp;name=' . htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ) . '&amp;description=' . htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa-rb fa-tumblr"></i></a>';
			}
			if ( ! empty( $enable_vk ) ) {
				$str .= '<a class="share-bar-el icon-vk"  href="' . $protocol . '://vkontakte.ru/share.php?url=' . urldecode( get_permalink() ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa-rb fa-vk"></i></a>';
			}
			if ( ! empty( $enable_reddit ) ) {
				$str .= '<a class="share-bar-el icon-reddit" href="' . $protocol . '://www.reddit.com/submit?url=' . urlencode( get_permalink() ) . '&title=' . htmlspecialchars( urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8' ) ), ENT_COMPAT, 'UTF-8' ) . '" onclick="window.open(this.href, \'mywin\',\'left=50,top=50,width=600,height=350,toolbar=0\'); return false;"><i class="fa-rb fa-reddit"></i></a>';
			}
			if ( ! empty( $enable_email ) ) {
				$str .= '<a class="share-bar-el icon-email" href="mailto:?subject=' . get_the_title() . '&amp;BODY=' . esc_html__( 'I found this article interesting and thought of sharing it with you. Check it out:', 'look' ) . urlencode( get_permalink() ) . '"><i class="fa-rb fa-envelope-o"></i></a>';
			}

			if ( ! empty( $enable_whatsapp ) ) {
				$str .= '<a class="share-bar-el icon-whatsapp" href="whatsapp://send?text=' . get_the_title() . ' - ' . get_permalink() . '" ><i class="fa-rb fa-whatsapp"></i></a>';
			}
			return $str;
		}

	}
}

if ( ! function_exists( 'look_ruby_twitter_ember_script' ) ) {
	function look_ruby_twitter_ember_script() {

		if ( isset( $GLOBALS['look_ruby_twitter_ember'] ) && true === $GLOBALS['look_ruby_twitter_ember'] ) {
			return '';
		}

		$GLOBALS['look_ruby_twitter_ember'] = true;

		return '<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>';
	}
}


