<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class look_ruby_flickr_data
 * flickr data
 */
if ( ! class_exists( 'look_ruby_flickr_data' ) ) {
	class look_ruby_flickr_data {

		/**
		 * @param string $flickr_id
		 * @param int    $num_images
		 * @param string $tags
		 *
		 * @return array|mixed
		 * get flickr data
		 */
		static function get_data( $flickr_id, $num_images = 9, $tags = '' ) {
			if ( empty( $flickr_id ) ) {
				return array();
			};

			$params = array(
				'timeout'   => 100,
				'sslverify' => false
			);

			$response = wp_remote_get( 'http://api.flickr.com/services/feeds/photos_public.gne?format=json&id=' . urlencode( $flickr_id ) . '&nojsoncallback=1&tags=' . urlencode( $tags ), $params );
			if ( is_wp_error( $response ) || '200' != $response['response']['code'] ) {
				return array();
			}
			$response = wp_remote_retrieve_body( $response );
			$response = str_replace( "\\'", "'", $response );
			$content  = json_decode( $response, true );
			if ( is_array( $content ) ) {
				$content = array_slice( $content['items'], 0, $num_images );
				foreach ( $content as $i => $v ) {
					$content[ $i ]['media'] = preg_replace( '/_m\.(jp?g|png|gif)$/', '_s.\\1', $v['media']['m'] );
				}

				return $content;
			} else {
				return array();
			}
		}
	}
}


/**
 * Class look_ruby_instagram_data
 * instagram data
 */
if ( ! class_exists( 'look_ruby_instagram_data' ) ) {
	class look_ruby_instagram_data {

		static function get_data( $instagram_token, $cache_name = '', $widget_id = '', $num_images = 9 ) {

			if ( ! empty( $instagram_token ) ) {

				$data_images = array();
				$params      = array(
					'sslverify' => false,
					'timeout'   => 100
				);

				$url      = 'https://graph.instagram.com/me/media?fields=id,caption,media_url,permalink&access_token=' . trim( $instagram_token );
				$response = wp_remote_get( $url, $params );

				if ( is_wp_error( $response ) || empty( $response['response']['code'] ) || 200 != $response['response']['code'] ) {
					return ' <div class="ruby-error">' . esc_html__( 'Could not connect to Instagram API server.', 'look-core' ) . '</div>';
				};

				$response = json_decode( wp_remote_retrieve_body( $response ) );

				if ( ! empty( $response->data ) && is_array( $response->data ) ) {
					foreach ( $response->data as $image ) {

						$caption   = esc_html__( 'instagram image', 'look-core' );
						$link      = '#';
						$likes     = '';
						$comments  = '';
						$thumbnail = '#';

						if ( ! empty( $image->permalink ) ) {
							$link = esc_url( $image->permalink );
						}

						if ( ! empty( $image->media_url ) ) {
							$thumbnail = esc_url( $image->media_url );
						}
						if ( ! empty( $image->$caption ) ) {
							$caption = wp_kses_post( $image->$caption );
						}

						$data_images[] = array(
							'thumbnail_src' => $thumbnail,
							'caption'       => wp_kses_post( $caption ),
							'link'          => $link,
							'likes'         => $likes,
							'comments'      => $comments
						);
					}

					$cache_data = get_transient( $cache_name );
					if ( ! is_array( $cache_data ) ) {
						$cache_data = array();
					}
					$cache_data[ $widget_id ] = $data_images;

					set_transient( $cache_name, $cache_data, 12000 );

					return $data_images;

				} else {
					return ' <div class="ruby-error">' . esc_html__( 'Not found images.', 'look-core' ) . '</div>';
				}

			} else {
				return ' <div class="ruby-error">' . esc_html__( 'Empty instagram token...', 'look-core' ) . '</div>';
			}
		}
	}
}

