<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'look_ruby_shortcodes' ) ) {
	class look_ruby_shortcodes {

		protected static $instance = null;

		function __construct() {

			add_shortcode( 'button', array( $this, 'shortcode_button' ) );
			add_shortcode( 'dropcap', array( $this, 'shortcode_dropcap' ) );
			add_shortcode( 'accordion', array( $this, 'shortcode_accordion_group' ) );
			add_shortcode( 'accordion-item', array( $this, 'ruby_accordion_item' ) );
			add_shortcode( 'row', array( $this, 'shortcode_row' ) );
			add_shortcode( 'column', array( $this, 'shortcode_column' ) );

		}

		static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}


		/**-------------------------------------------------------------------------------------------------------------------------
		 * @param      $attrs
		 * @param null $content
		 *
		 * @return string
		 * button shortcode
		 */
		static function shortcode_button( $attrs, $content = null ) {
			extract( shortcode_atts( array(
				'type'   => '',
				'color'  => '',
				'target' => '',
				'link'   => ''
			), $attrs ) );

			$classes      = array();
			$style_inline = '';
			$str          = '';

			$classes[] = 'btn shortcode-btn';
			if ( ! empty( $type ) ) {
				$classes[] = 'is-' . esc_attr( $type );
			} else {
				$classes[] = 'is-default';
			}

			if ( ! empty( $color ) ) {
				$style_inline = 'style="background-color: ' . strip_tags( $color ) . '"';
			}

			if ( ! empty( $link ) ) {
				$link = esc_url( $link );
			} else {
				$link = '#';
			}

			if ( ! empty( $target ) ) {
				$target = 'target="_blank"';
			} else {
				$target = '';
			}

			$classes = implode( ' ', $classes );

			$str .= '<a class="' . $classes . '" ' . $style_inline . ' ' . $target . ' href="' . $link . '">';
			$str .= esc_html( $content );
			$str .= '</a>';

			return $str;

		}


		/**-------------------------------------------------------------------------------------------------------------------------
		 * @param      $attrs
		 * @param null $content
		 *
		 * @return string
		 * dropcap shortcode
		 */
		static function shortcode_dropcap( $attrs, $content = null ) {
			extract( shortcode_atts( array(
				'type' => '',
			), $attrs ) );

			$classes   = array();
			$classes[] = 'shortcode-dropcap';

			if ( empty( $type ) ) {
				$classes[] = 'is-default';
			} else {
				$classes[] = 'is-' . esc_attr( $type );
			}

			$classes = implode( ' ', $classes );

			return '<span class="' . esc_attr( $classes ) . '">' . $content . '</span>';
		}


		/**-------------------------------------------------------------------------------------------------------------------------
		 * @param      $attrs
		 * @param null $content
		 *
		 * @return string
		 * accordion shortcode
		 */
		static function shortcode_accordion_group( $attrs, $content = null ) {
			return '<div class="shortcode-accordion">' . apply_filters( 'the_content', $content ) . ' </div>';
		}

		static function ruby_accordion_item( $attrs, $content = null ) {
			extract( shortcode_atts( array(
				'title' => '',
			), $attrs ) );

			if ( empty( $title ) ) {
				$title = '';
			}

			$str = '';
			$str .= '<h3 class="accordion-item-title">' . esc_html( $title ) . '</h3>';
			$str .= '<div class="accordion-item-content accordion-hide">' . apply_filters( 'the_content', $content ) . '</div>';

			return $str;

		}


		/**-------------------------------------------------------------------------------------------------------------------------
		 * @param      $attrs
		 * @param null $content
		 *
		 * @return string
		 * row shortcodes
		 */
		static function shortcode_row( $attrs, $content = null ) {

			return '<div class="shortcode-row row clearfix">' . apply_filters( 'the_content', $content ) . '</div>';

		}


		/**-------------------------------------------------------------------------------------------------------------------------
		 * @param      $attrs
		 * @param null $content
		 *
		 * @return string
		 * column shortcode
		 */
		static function shortcode_column( $attrs, $content = null ) {

			extract( shortcode_atts( array(
				'width' => ''
			), $attrs ) );

			if ( empty( $width ) ) {
				$width = '100%';
			}

			switch ( $width ) {
				case '50%'  :
					return '<div class="shortcode-col col-sm-6 col-sx-12">' . apply_filters( 'the_content', $content ) . '</div>';
				case '33%'  :
					return '<div class="shortcode-col col-sm-4 col-sx-12">' . apply_filters( 'the_content', $content ) . '</div>';
				case '66%' :
					return '<div class="shortcode-col col-sm-8 col-sx-12">' . apply_filters( 'the_content', $content ) . '</div>';
				case '25%' :
					return '<div class="shortcode-col col-sm-3 col-sx-12">' . apply_filters( 'the_content', $content ) . '</div>';
				default :
					return '<div class="shortcode-col col-xs-12">' . apply_filters( 'the_content', $content ) . '</div>';
			}
		}

	}
}
