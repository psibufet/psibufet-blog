<?php
//  No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_head', 'look_ruby_opengraph_meta', 10 );


if ( ! function_exists( 'look_ruby_opengraph_meta' ) ) {
	function look_ruby_opengraph_meta() {
		global $post;

		$open_graph = look_ruby_get_option( 'open_graph' );
		if ( ! is_singular() || empty( $open_graph ) ) {
			return false;
		}

		if ( class_exists( 'WPSEO_Frontend' ) ) {
			$yoast_social = get_option( 'wpseo_social' );
			if ( ! empty( $yoast_social['opengraph'] ) ) {
				return false;
			}
		}

		$post_excerpt = '';
		if ( ! is_front_page() && is_page() ) {
			if ( ! empty( $post->post_excerpt ) ) {
				$post_excerpt = $post->post_excerpt;
			} else {
				$post_content = preg_replace( '`\[[^\]]*\]`', '', $post->post_content );
				$post_content = stripslashes( wp_filter_nohtml_kses( $post_content ) );
				$post_excerpt = wp_trim_words( esc_html( $post_content ), 30, '' );
			}
		}

		echo '<meta property="og:title" content="' . get_the_title() . '"/>';
		echo '<meta property="og:url" content="' . get_permalink() . '"/>';
		echo '<meta property="og:site_name" content="' . get_bloginfo( 'name' ) . '"/>';
		echo '<meta property="og:description" content="' . strip_tags( esc_attr( $post_excerpt ) ) . '"/>';
		if ( has_post_thumbnail( $post->ID ) ) {
			$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
			echo '<meta property="og:image" content="' . esc_url( $thumbnail_src[0] ) . '"/>';
		}
	}
}
